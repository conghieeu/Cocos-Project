window._CCSettings = {
  platform: "web-mobile",
  groupList: ["default"],
  collisionMatrix: [[true]],
  hasResourcesBundle: true,
  hasStartSceneBundle: false,
  remoteBundles: [], // giữ rỗng
  subpackages: [], // giữ rỗng
  launchScene: "db://assets/Scene/Scene.fire",
  orientation: "",
  jsList: [],
  optimizeTextures: true,
  cleanupImageCache: true
};
